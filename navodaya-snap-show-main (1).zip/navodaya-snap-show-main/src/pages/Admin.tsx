import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import {
  Trash2, Upload, LogOut, LogIn, Image, FileText, Trophy, Save,
  Mail, Megaphone, BookOpen, Menu, X, Eye, EyeOff, Video, Users, Reply, Send,
} from "lucide-react";

const Admin = () => {
  const { toast } = useToast();
  const [session, setSession] = useState<any>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("photos");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      setLoading(false);
    });
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setLoading(false);
    });
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      toast({ title: "Login failed", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Logged in!" });
    }
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-background"><p className="text-muted-foreground">Loading...</p></div>;

  if (!session) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background px-4">
        <form onSubmit={handleLogin} className="w-full max-w-sm space-y-4 bg-card p-8 rounded-2xl shadow-lg border border-border">
          <h1 className="text-2xl font-black text-center text-foreground">🔐 Admin Login</h1>
          <p className="text-sm text-muted-foreground text-center">JNV Buklana Bulandshahr</p>
          <Input placeholder="Email" type="email" value={email} onChange={e => setEmail(e.target.value)} />
          <Input placeholder="Password" type="password" value={password} onChange={e => setPassword(e.target.value)} />
          <Button type="submit" className="w-full gap-2"><LogIn size={18} /> Login</Button>
          <a href="/" className="block text-center text-sm text-primary hover:underline mt-2">← Back to Website</a>
        </form>
      </div>
    );
  }

  const tabs = [
    { id: "photos", label: "Photos", icon: Image, emoji: "📸" },
    { id: "videos", label: "Videos", icon: Video, emoji: "🎬" },
    { id: "content", label: "Site Content", icon: FileText, emoji: "📝" },
    { id: "achievements", label: "Achievements", icon: Trophy, emoji: "🏆" },
    { id: "staff", label: "Staff Messages", icon: Users, emoji: "👨‍🏫" },
    { id: "inbox", label: "Inbox", icon: Mail, emoji: "✉️" },
    { id: "notices", label: "Notice Board", icon: Megaphone, emoji: "📢" },
    { id: "study", label: "Study Materials", icon: BookOpen, emoji: "📚" },
  ];

  return (
    <div className="min-h-screen bg-background flex">
      {sidebarOpen && (
        <div className="fixed inset-0 bg-foreground/40 z-40 md:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      <aside className={`fixed md:sticky top-0 left-0 h-screen w-64 bg-card border-r border-border z-50 flex flex-col transition-transform ${sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"}`}>
        <div className="p-4 border-b border-border">
          <h1 className="text-lg font-black text-foreground">📋 Admin Panel</h1>
          <p className="text-xs text-muted-foreground">JNV Buklana Bulandshahr</p>
        </div>
        <nav className="flex-1 p-2 space-y-1 overflow-y-auto">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => { setTab(t.id); setSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-semibold transition-colors ${
                tab === t.id ? "bg-primary text-primary-foreground" : "text-foreground/70 hover:bg-muted"
              }`}
            >
              <span>{t.emoji}</span> {t.label}
            </button>
          ))}
        </nav>
        <div className="p-3 border-t border-border space-y-2">
          <a href="/"><Button variant="outline" size="sm" className="w-full">🌐 View Site</Button></a>
          <Button variant="destructive" size="sm" className="w-full gap-1" onClick={async () => { await supabase.auth.signOut(); setSession(null); }}>
            <LogOut size={14} /> Logout
          </Button>
        </div>
      </aside>

      <div className="flex-1 min-w-0">
        <header className="sticky top-0 z-30 bg-card/90 backdrop-blur-md border-b border-border px-4 py-3 flex items-center gap-3 md:hidden">
          <button onClick={() => setSidebarOpen(true)} className="p-2 rounded-lg hover:bg-muted">
            <Menu size={20} />
          </button>
          <h2 className="font-bold text-foreground">{tabs.find(t => t.id === tab)?.emoji} {tabs.find(t => t.id === tab)?.label}</h2>
        </header>
        <main className="max-w-4xl mx-auto p-4 sm:p-8">
          {tab === "photos" && <PhotosTab />}
          {tab === "videos" && <VideosTab />}
          {tab === "content" && <ContentTab />}
          {tab === "achievements" && <AchievementsTab />}
          {tab === "staff" && <StaffTab />}
          {tab === "inbox" && <InboxTab />}
          {tab === "notices" && <NoticesTab />}
          {tab === "study" && <StudyMaterialsTab />}
        </main>
      </div>
    </div>
  );
};

/* ─── Photos Tab ─── */
const PhotosTab = () => {
  const { toast } = useToast();
  const [photos, setPhotos] = useState<any[]>([]);
  const [uploading, setUploading] = useState(false);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("general");
  const [file, setFile] = useState<File | null>(null);

  useEffect(() => { fetchPhotos(); }, []);
  const fetchPhotos = async () => {
    const { data } = await supabase.from("school_photos").select("*").order("created_at", { ascending: false });
    if (data) setPhotos(data);
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file || !title) { toast({ title: "Please select a file and enter a title", variant: "destructive" }); return; }
    setUploading(true);
    try {
      const fileName = `${Date.now()}.${file.name.split(".").pop()}`;
      const { error: uploadError } = await supabase.storage.from("school-photos").upload(fileName, file);
      if (uploadError) throw uploadError;
      const { data: { publicUrl } } = supabase.storage.from("school-photos").getPublicUrl(fileName);
      const { error: dbError } = await supabase.from("school_photos").insert({ title, image_url: publicUrl, category });
      if (dbError) throw dbError;
      toast({ title: "Photo uploaded!" });
      setTitle(""); setCategory("general"); setFile(null);
      fetchPhotos();
    } catch (err: any) {
      toast({ title: "Upload failed", description: err.message, variant: "destructive" });
    } finally { setUploading(false); }
  };

  const handleDelete = async (photo: any) => {
    const fileName = photo.image_url.split("/").pop();
    await supabase.storage.from("school-photos").remove([fileName]);
    await supabase.from("school_photos").delete().eq("id", photo.id);
    toast({ title: "Photo deleted" });
    fetchPhotos();
  };

  return (
    <div className="space-y-8">
      <form onSubmit={handleUpload} className="bg-card p-6 rounded-2xl shadow-md border border-border space-y-4">
        <h2 className="text-lg font-bold text-foreground flex items-center gap-2"><Upload size={20} /> Upload New Photo</h2>
        <Input placeholder="Photo title" value={title} onChange={e => setTitle(e.target.value)} maxLength={100} />
        <select value={category} onChange={e => setCategory(e.target.value)} className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm">
          <option value="general">General</option><option value="sports">Sports</option><option value="cultural">Cultural</option><option value="academic">Academic</option><option value="campus">Campus</option>
        </select>
        <Input type="file" accept="image/*" onChange={e => setFile(e.target.files?.[0] || null)} />
        <Button type="submit" disabled={uploading} className="w-full gap-2"><Image size={18} />{uploading ? "Uploading..." : "Upload Photo"}</Button>
      </form>
      <div>
        <h2 className="text-lg font-bold text-foreground mb-4">📸 All Photos ({photos.length})</h2>
        {photos.length === 0 ? <p className="text-muted-foreground text-center py-10">No photos yet.</p> : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {photos.map(photo => (
              <div key={photo.id} className="bg-card rounded-xl overflow-hidden shadow-md border border-border">
                <img src={photo.image_url} alt={photo.title} className="w-full h-40 object-cover" />
                <div className="p-3">
                  <p className="font-bold text-foreground text-sm">{photo.title}</p>
                  <p className="text-xs text-muted-foreground capitalize">{photo.category}</p>
                  <Button variant="destructive" size="sm" className="mt-2 w-full gap-1" onClick={() => handleDelete(photo)}><Trash2 size={14} /> Delete</Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

/* ─── Videos Tab ─── */
const VideosTab = () => {
  const { toast } = useToast();
  const [videos, setVideos] = useState<any[]>([]);
  const [uploading, setUploading] = useState(false);
  const [title, setTitle] = useState("");
  const [videoType, setVideoType] = useState("youtube");
  const [youtubeUrl, setYoutubeUrl] = useState("");
  const [file, setFile] = useState<File | null>(null);

  useEffect(() => { fetchVideos(); }, []);
  const fetchVideos = async () => {
    const { data } = await supabase.from("school_videos").select("*").order("display_order");
    if (data) setVideos(data);
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) { toast({ title: "Please enter a title", variant: "destructive" }); return; }
    setUploading(true);
    try {
      let videoUrl = "";
      let thumbnailUrl = "";

      if (videoType === "youtube") {
        if (!youtubeUrl.trim()) { toast({ title: "Please enter a YouTube URL", variant: "destructive" }); setUploading(false); return; }
        videoUrl = youtubeUrl.trim();
        // Auto-generate thumbnail
        const match = videoUrl.match(/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([a-zA-Z0-9_-]+)/);
        if (match) thumbnailUrl = `https://img.youtube.com/vi/${match[1]}/hqdefault.jpg`;
      } else {
        if (!file) { toast({ title: "Please select a video file", variant: "destructive" }); setUploading(false); return; }
        const fileName = `videos/${Date.now()}_${file.name}`;
        const { error: uploadError } = await supabase.storage.from("school-photos").upload(fileName, file);
        if (uploadError) throw uploadError;
        const { data: { publicUrl } } = supabase.storage.from("school-photos").getPublicUrl(fileName);
        videoUrl = publicUrl;
      }

      const { error } = await supabase.from("school_videos").insert({
        title, video_type: videoType, video_url: videoUrl, thumbnail_url: thumbnailUrl, display_order: videos.length,
      });
      if (error) throw error;
      toast({ title: "Video added!" });
      setTitle(""); setYoutubeUrl(""); setFile(null);
      fetchVideos();
    } catch (err: any) {
      toast({ title: "Failed", description: err.message, variant: "destructive" });
    } finally { setUploading(false); }
  };

  const handleDelete = async (v: any) => {
    if (v.video_type === "mp4" && v.video_url.includes("school-photos")) {
      const path = v.video_url.split("/school-photos/")[1];
      if (path) await supabase.storage.from("school-photos").remove([decodeURIComponent(path)]);
    }
    await supabase.from("school_videos").delete().eq("id", v.id);
    toast({ title: "Video deleted" });
    fetchVideos();
  };

  return (
    <div className="space-y-8">
      <form onSubmit={handleAdd} className="bg-card p-6 rounded-2xl shadow-md border border-border space-y-4">
        <h2 className="text-lg font-bold text-foreground flex items-center gap-2"><Video size={20} /> Add Video</h2>
        <Input placeholder="Video title" value={title} onChange={e => setTitle(e.target.value)} maxLength={200} />
        <div className="flex gap-2">
          <button type="button" onClick={() => setVideoType("youtube")}
            className={`flex-1 py-2 rounded-lg text-sm font-bold transition-colors ${videoType === "youtube" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground/70"}`}>
            🔗 YouTube Link
          </button>
          <button type="button" onClick={() => setVideoType("mp4")}
            className={`flex-1 py-2 rounded-lg text-sm font-bold transition-colors ${videoType === "mp4" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground/70"}`}>
            📁 Upload MP4
          </button>
        </div>
        {videoType === "youtube" ? (
          <Input placeholder="YouTube URL (e.g. https://youtube.com/watch?v=...)" value={youtubeUrl} onChange={e => setYoutubeUrl(e.target.value)} />
        ) : (
          <Input type="file" accept="video/mp4,video/webm" onChange={e => setFile(e.target.files?.[0] || null)} />
        )}
        <Button type="submit" disabled={uploading} className="w-full gap-2"><Video size={18} />{uploading ? "Adding..." : "Add Video"}</Button>
      </form>
      <div>
        <h2 className="text-lg font-bold text-foreground mb-4">🎬 All Videos ({videos.length})</h2>
        {videos.length === 0 ? <p className="text-muted-foreground text-center py-10">No videos yet.</p> : (
          <div className="space-y-3">
            {videos.map(v => (
              <div key={v.id} className="bg-card p-4 rounded-xl border border-border flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  {v.thumbnail_url && <img src={v.thumbnail_url} alt="" className="w-20 h-12 object-cover rounded-lg" />}
                  <div className="min-w-0">
                    <p className="font-bold text-foreground text-sm truncate">{v.title}</p>
                    <p className="text-xs text-muted-foreground uppercase">{v.video_type}</p>
                  </div>
                </div>
                <Button variant="destructive" size="sm" onClick={() => handleDelete(v)}><Trash2 size={14} /></Button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

/* ─── Content Tab ─── */
const ContentTab = () => {
  const { toast } = useToast();
  const [items, setItems] = useState<any[]>([]);
  const [saving, setSaving] = useState<string | null>(null);

  useEffect(() => { fetchContent(); }, []);
  const fetchContent = async () => {
    const { data } = await supabase.from("site_content").select("*").order("section");
    if (data) setItems(data);
  };

  const handleSave = async (item: any) => {
    setSaving(item.id);
    const { error } = await supabase.from("site_content").update({ value: item.value }).eq("id", item.id);
    if (error) toast({ title: "Save failed", description: error.message, variant: "destructive" });
    else toast({ title: `"${item.label}" saved!` });
    setSaving(null);
  };

  const updateValue = (id: string, value: string) => setItems(prev => prev.map(i => i.id === id ? { ...i, value } : i));

  const sectionLabels: Record<string, string> = { hero: "🏠 Hero", about: "🏫 About", contact: "📞 Contact", stats: "📊 Stats", general: "⚙️ General" };
  const sections = [...new Set(items.map(i => i.section))];

  return (
    <div className="space-y-8">
      <div className="bg-card p-4 rounded-2xl shadow-md border border-border">
        <p className="text-sm text-muted-foreground">✏️ Edit text below and click <strong>Save</strong> to update the website instantly.</p>
      </div>
      {sections.map(section => (
        <div key={section} className="space-y-4">
          <h2 className="text-lg font-bold text-foreground">{sectionLabels[section] || section}</h2>
          {items.filter(i => i.section === section).map(item => (
            <div key={item.id} className="bg-card p-4 rounded-xl border border-border space-y-2">
              <label className="text-sm font-bold text-foreground">{item.label}</label>
              {item.value.length > 80 ? (
                <Textarea value={item.value} onChange={e => updateValue(item.id, e.target.value)} className="min-h-[100px]" />
              ) : (
                <Input value={item.value} onChange={e => updateValue(item.id, e.target.value)} />
              )}
              <Button size="sm" onClick={() => handleSave(item)} disabled={saving === item.id} className="gap-1">
                <Save size={14} /> {saving === item.id ? "Saving..." : "Save"}
              </Button>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
};

/* ─── Achievements Tab ─── */
const AchievementsTab = () => {
  const { toast } = useToast();
  const [items, setItems] = useState<any[]>([]);
  const [form, setForm] = useState({ title: "", description: "", year: "2024", icon_name: "Trophy", color_theme: "blue" });

  useEffect(() => { fetchAchievements(); }, []);
  const fetchAchievements = async () => {
    const { data } = await supabase.from("school_achievements").select("*").order("display_order");
    if (data) setItems(data);
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title || !form.description) { toast({ title: "Fill title and description", variant: "destructive" }); return; }
    const { error } = await supabase.from("school_achievements").insert({ ...form, display_order: items.length });
    if (error) { toast({ title: "Failed", description: error.message, variant: "destructive" }); return; }
    toast({ title: "Achievement added!" });
    setForm({ title: "", description: "", year: "2024", icon_name: "Trophy", color_theme: "blue" });
    fetchAchievements();
  };

  const handleDelete = async (id: string) => {
    await supabase.from("school_achievements").delete().eq("id", id);
    toast({ title: "Achievement deleted" });
    fetchAchievements();
  };

  return (
    <div className="space-y-8">
      <form onSubmit={handleAdd} className="bg-card p-6 rounded-2xl shadow-md border border-border space-y-4">
        <h2 className="text-lg font-bold text-foreground flex items-center gap-2"><Trophy size={20} /> Add Achievement</h2>
        <Input placeholder="Title" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} maxLength={200} />
        <Textarea placeholder="Description" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} maxLength={500} />
        <div className="grid grid-cols-3 gap-3">
          <Input placeholder="Year" value={form.year} onChange={e => setForm({ ...form, year: e.target.value })} />
          <select value={form.icon_name} onChange={e => setForm({ ...form, icon_name: e.target.value })} className="rounded-lg border border-input bg-background px-3 py-2 text-sm">
            <option value="Trophy">🏆 Trophy</option><option value="Medal">🥇 Medal</option><option value="Star">⭐ Star</option><option value="Award">🎖️ Award</option>
          </select>
          <select value={form.color_theme} onChange={e => setForm({ ...form, color_theme: e.target.value })} className="rounded-lg border border-input bg-background px-3 py-2 text-sm">
            <option value="blue">🔵 Blue</option><option value="green">🟢 Green</option><option value="orange">🟠 Orange</option><option value="yellow">🟡 Yellow</option><option value="purple">🟣 Purple</option>
          </select>
        </div>
        <Button type="submit" className="w-full gap-2"><Trophy size={18} /> Add Achievement</Button>
      </form>
      <div>
        <h2 className="text-lg font-bold text-foreground mb-4">🏆 All Achievements ({items.length})</h2>
        {items.length === 0 ? <p className="text-muted-foreground text-center py-10">No achievements yet.</p> : (
          <div className="space-y-3">
            {items.map(item => (
              <div key={item.id} className="bg-card p-4 rounded-xl border border-border flex items-center justify-between">
                <div><p className="font-bold text-foreground">{item.title}</p><p className="text-sm text-muted-foreground">{item.description} • {item.year}</p></div>
                <Button variant="destructive" size="sm" onClick={() => handleDelete(item.id)}><Trash2 size={14} /></Button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

/* ─── Staff Messages Tab ─── */
const StaffTab = () => {
  const { toast } = useToast();
  const [staff, setStaff] = useState<any[]>([]);
  const [uploading, setUploading] = useState(false);
  const [form, setForm] = useState({ name: "", role: "Principal", message: "" });
  const [photoFile, setPhotoFile] = useState<File | null>(null);

  useEffect(() => { fetchStaff(); }, []);
  const fetchStaff = async () => {
    const { data } = await supabase.from("staff_messages").select("*").order("display_order");
    if (data) setStaff(data);
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.message) { toast({ title: "Fill name and message", variant: "destructive" }); return; }
    setUploading(true);
    try {
      let photoUrl = "";
      if (photoFile) {
        const fileName = `staff/${Date.now()}.${photoFile.name.split(".").pop()}`;
        const { error: uploadError } = await supabase.storage.from("school-photos").upload(fileName, photoFile);
        if (uploadError) throw uploadError;
        const { data: { publicUrl } } = supabase.storage.from("school-photos").getPublicUrl(fileName);
        photoUrl = publicUrl;
      }
      const { error } = await supabase.from("staff_messages").insert({
        name: form.name, role: form.role, message: form.message, photo_url: photoUrl, display_order: staff.length,
      });
      if (error) throw error;
      toast({ title: "Staff message added!" });
      setForm({ name: "", role: "Principal", message: "" });
      setPhotoFile(null);
      fetchStaff();
    } catch (err: any) {
      toast({ title: "Failed", description: err.message, variant: "destructive" });
    } finally { setUploading(false); }
  };

  const handleDelete = async (s: any) => {
    if (s.photo_url && s.photo_url.includes("school-photos")) {
      const path = s.photo_url.split("/school-photos/")[1];
      if (path) await supabase.storage.from("school-photos").remove([decodeURIComponent(path)]);
    }
    await supabase.from("staff_messages").delete().eq("id", s.id);
    toast({ title: "Deleted" });
    fetchStaff();
  };

  return (
    <div className="space-y-8">
      <form onSubmit={handleAdd} className="bg-card p-6 rounded-2xl shadow-md border border-border space-y-4">
        <h2 className="text-lg font-bold text-foreground flex items-center gap-2"><Users size={20} /> Add Staff Message</h2>
        <Input placeholder="Name (e.g. Shri Ram Kumar)" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} maxLength={100} />
        <select value={form.role} onChange={e => setForm({ ...form, role: e.target.value })} className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm">
          <option value="Principal">Principal</option>
          <option value="Vice Principal">Vice Principal</option>
          <option value="Head Master">Head Master</option>
          <option value="Teacher">Teacher</option>
          <option value="Staff">Staff</option>
          <option value="Alumni">Alumni</option>
        </select>
        <Textarea placeholder="Message" value={form.message} onChange={e => setForm({ ...form, message: e.target.value })} maxLength={1000} className="min-h-[100px]" />
        <Input type="file" accept="image/*" onChange={e => setPhotoFile(e.target.files?.[0] || null)} />
        <p className="text-xs text-muted-foreground">📸 Upload a photo of the person (optional)</p>
        <Button type="submit" disabled={uploading} className="w-full gap-2"><Users size={18} />{uploading ? "Adding..." : "Add Staff Message"}</Button>
      </form>
      <div>
        <h2 className="text-lg font-bold text-foreground mb-4">👨‍🏫 All Staff Messages ({staff.length})</h2>
        {staff.length === 0 ? <p className="text-muted-foreground text-center py-10">No staff messages yet.</p> : (
          <div className="space-y-3">
            {staff.map(s => (
              <div key={s.id} className="bg-card p-4 rounded-xl border border-border flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  {s.photo_url ? (
                    <img src={s.photo_url} alt={s.name} className="w-12 h-12 rounded-full object-cover" />
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center"><Users size={20} className="text-primary" /></div>
                  )}
                  <div className="min-w-0">
                    <p className="font-bold text-foreground text-sm">{s.name}</p>
                    <p className="text-xs text-primary font-semibold">{s.role}</p>
                    <p className="text-xs text-muted-foreground truncate">{s.message.slice(0, 80)}...</p>
                  </div>
                </div>
                <Button variant="destructive" size="sm" onClick={() => handleDelete(s)}><Trash2 size={14} /></Button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

/* ─── Inbox Tab ─── */
const InboxTab = () => {
  const { toast } = useToast();
  const [messages, setMessages] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyText, setReplyText] = useState("");
  const [sending, setSending] = useState(false);

  useEffect(() => { fetchMessages(); }, []);
  const fetchMessages = async () => {
    const { data } = await supabase.from("contact_messages").select("*").order("created_at", { ascending: false });
    if (data) setMessages(data);
    setLoading(false);
  };

  const toggleRead = async (msg: any) => {
    await supabase.from("contact_messages").update({ is_read: !msg.is_read }).eq("id", msg.id);
    fetchMessages();
  };

  const handleDelete = async (id: string) => {
    await supabase.from("contact_messages").delete().eq("id", id);
    toast({ title: "Message deleted" });
    fetchMessages();
  };

  const handleReply = (msg: any) => {
    if (replyingTo === msg.id) {
      setReplyingTo(null);
      setReplyText("");
    } else {
      setReplyingTo(msg.id);
      setReplyText("");
    }
  };

  const sendReply = async (msg: any) => {
    if (!replyText.trim()) { toast({ title: "Please type a reply", variant: "destructive" }); return; }
    setSending(true);
    try {
      // Open mailto link with pre-filled content
      const subject = encodeURIComponent(`Re: ${msg.subject || "Your message to JNV Buklana"}`);
      const body = encodeURIComponent(
        `Dear ${msg.name},\n\n${replyText}\n\n---\nOriginal message:\n"${msg.message}"\n\nBest regards,\nJNV Buklana Admin`
      );
      window.open(`mailto:${msg.email}?subject=${subject}&body=${body}`, "_blank");

      // Mark as read
      if (!msg.is_read) {
        await supabase.from("contact_messages").update({ is_read: true }).eq("id", msg.id);
      }
      toast({ title: "Reply opened in your email client!" });
      setReplyingTo(null);
      setReplyText("");
      fetchMessages();
    } catch (err: any) {
      toast({ title: "Failed", description: err.message, variant: "destructive" });
    } finally { setSending(false); }
  };

  const unreadCount = messages.filter(m => !m.is_read).length;

  return (
    <div className="space-y-6">
      <div className="bg-card p-4 rounded-2xl shadow-md border border-border flex items-center justify-between">
        <h2 className="text-lg font-bold text-foreground">✉️ Messages ({messages.length})</h2>
        {unreadCount > 0 && <span className="bg-destructive text-destructive-foreground px-3 py-1 rounded-full text-xs font-bold">{unreadCount} unread</span>}
      </div>
      {loading ? <p className="text-center text-muted-foreground py-10">Loading...</p> : messages.length === 0 ? (
        <p className="text-muted-foreground text-center py-16">No messages yet. Messages from the Contact form will appear here.</p>
      ) : (
        <div className="space-y-3">
          {messages.map(msg => (
            <div key={msg.id} className={`bg-card p-4 rounded-xl border shadow-sm ${msg.is_read ? "border-border" : "border-primary/40 bg-primary/5"}`}>
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-bold text-foreground text-sm">{msg.name}</p>
                    <span className="text-xs text-muted-foreground">{msg.email}</span>
                    {!msg.is_read && <span className="bg-primary text-primary-foreground text-[10px] px-2 py-0.5 rounded-full font-bold">NEW</span>}
                  </div>
                  {msg.subject && <p className="text-sm font-semibold text-foreground/80 mt-1">{msg.subject}</p>}
                  <p className="text-sm text-muted-foreground mt-1 whitespace-pre-wrap">{msg.message}</p>
                  <p className="text-xs text-muted-foreground mt-2">{new Date(msg.created_at).toLocaleString()}</p>
                </div>
                <div className="flex gap-1 flex-shrink-0">
                  <Button variant="ghost" size="icon" onClick={() => handleReply(msg)} title="Reply" className="text-primary hover:text-primary">
                    <Reply size={14} />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => toggleRead(msg)} title={msg.is_read ? "Mark unread" : "Mark read"}>
                    {msg.is_read ? <EyeOff size={14} /> : <Eye size={14} />}
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => handleDelete(msg.id)} className="text-destructive hover:text-destructive">
                    <Trash2 size={14} />
                  </Button>
                </div>
              </div>
              {/* Reply box */}
              {replyingTo === msg.id && (
                <div className="mt-3 pt-3 border-t border-border space-y-2">
                  <Textarea
                    placeholder={`Reply to ${msg.name}...`}
                    value={replyText}
                    onChange={e => setReplyText(e.target.value)}
                    className="min-h-[80px]"
                    maxLength={2000}
                  />
                  <div className="flex gap-2 justify-end">
                    <Button variant="outline" size="sm" onClick={() => { setReplyingTo(null); setReplyText(""); }}>Cancel</Button>
                    <Button size="sm" className="gap-1" onClick={() => sendReply(msg)} disabled={sending}>
                      <Send size={14} /> {sending ? "Opening..." : "Send Reply"}
                    </Button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

/* ─── Notices Tab ─── */
const NoticesTab = () => {
  const { toast } = useToast();
  const [notices, setNotices] = useState<any[]>([]);
  const [text, setText] = useState("");

  useEffect(() => { fetchNotices(); }, []);
  const fetchNotices = async () => {
    const { data } = await supabase.from("notices").select("*").order("created_at", { ascending: false });
    if (data) setNotices(data);
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    const { error } = await supabase.from("notices").insert({ text: text.trim() });
    if (error) { toast({ title: "Failed", description: error.message, variant: "destructive" }); return; }
    toast({ title: "Notice added!" });
    setText("");
    fetchNotices();
  };

  const toggleActive = async (notice: any) => {
    await supabase.from("notices").update({ active: !notice.active }).eq("id", notice.id);
    fetchNotices();
  };

  const handleDelete = async (id: string) => {
    await supabase.from("notices").delete().eq("id", id);
    toast({ title: "Notice deleted" });
    fetchNotices();
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleAdd} className="bg-card p-6 rounded-2xl shadow-md border border-border space-y-4">
        <h2 className="text-lg font-bold text-foreground flex items-center gap-2"><Megaphone size={20} /> Add Notice</h2>
        <Input placeholder="Notice text (e.g. Exam starts from 15th March)" value={text} onChange={e => setText(e.target.value)} maxLength={300} />
        <Button type="submit" className="w-full gap-2"><Megaphone size={18} /> Add Notice</Button>
      </form>
      <div>
        <h2 className="text-lg font-bold text-foreground mb-4">📢 All Notices ({notices.length})</h2>
        {notices.length === 0 ? <p className="text-muted-foreground text-center py-10">No notices yet.</p> : (
          <div className="space-y-3">
            {notices.map(n => (
              <div key={n.id} className={`bg-card p-4 rounded-xl border flex items-center justify-between gap-3 ${n.active ? "border-school-green/40" : "border-border opacity-60"}`}>
                <div className="min-w-0 flex-1">
                  <p className="font-semibold text-foreground text-sm">{n.text}</p>
                  <p className="text-xs text-muted-foreground mt-1">{n.active ? "🟢 Active" : "⚪ Inactive"}</p>
                </div>
                <div className="flex gap-1">
                  <Button variant="outline" size="sm" onClick={() => toggleActive(n)}>{n.active ? "Hide" : "Show"}</Button>
                  <Button variant="destructive" size="sm" onClick={() => handleDelete(n.id)}><Trash2 size={14} /></Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

/* ─── Study Materials Tab ─── */
const StudyMaterialsTab = () => {
  const { toast } = useToast();
  const [materials, setMaterials] = useState<any[]>([]);
  const [uploading, setUploading] = useState(false);
  const [title, setTitle] = useState("");
  const [classNumber, setClassNumber] = useState("6");
  const [category, setCategory] = useState("general");
  const [file, setFile] = useState<File | null>(null);

  useEffect(() => { fetchMaterials(); }, []);
  const fetchMaterials = async () => {
    const { data } = await supabase.from("study_materials").select("*").order("class_number").order("created_at", { ascending: false });
    if (data) setMaterials(data);
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file || !title) { toast({ title: "Please select a file and enter a title", variant: "destructive" }); return; }
    setUploading(true);
    try {
      const fileName = `class${classNumber}/${Date.now()}_${file.name}`;
      const { error: uploadError } = await supabase.storage.from("study-materials").upload(fileName, file);
      if (uploadError) throw uploadError;
      const { data: { publicUrl } } = supabase.storage.from("study-materials").getPublicUrl(fileName);
      const { error: dbError } = await supabase.from("study_materials").insert({
        title, class_number: parseInt(classNumber), category, file_url: publicUrl,
      });
      if (dbError) throw dbError;
      toast({ title: "Material uploaded!" });
      setTitle(""); setFile(null);
      fetchMaterials();
    } catch (err: any) {
      toast({ title: "Upload failed", description: err.message, variant: "destructive" });
    } finally { setUploading(false); }
  };

  const handleDelete = async (m: any) => {
    const path = m.file_url.split("/study-materials/")[1];
    if (path) await supabase.storage.from("study-materials").remove([decodeURIComponent(path)]);
    await supabase.from("study_materials").delete().eq("id", m.id);
    toast({ title: "Material deleted" });
    fetchMaterials();
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleUpload} className="bg-card p-6 rounded-2xl shadow-md border border-border space-y-4">
        <h2 className="text-lg font-bold text-foreground flex items-center gap-2"><BookOpen size={20} /> Upload Study Material</h2>
        <Input placeholder="Title (e.g. Maths Previous Year Paper 2024)" value={title} onChange={e => setTitle(e.target.value)} maxLength={200} />
        <div className="grid grid-cols-2 gap-3">
          <select value={classNumber} onChange={e => setClassNumber(e.target.value)} className="rounded-lg border border-input bg-background px-3 py-2 text-sm">
            {[6,7,8,9,10,11,12].map(c => <option key={c} value={c}>Class {c}</option>)}
          </select>
          <select value={category} onChange={e => setCategory(e.target.value)} className="rounded-lg border border-input bg-background px-3 py-2 text-sm">
            <option value="general">General</option><option value="syllabus">Syllabus</option><option value="previous-papers">Previous Papers</option><option value="study-guide">Study Guide</option>
          </select>
        </div>
        <Input type="file" accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.jpg,.png" onChange={e => setFile(e.target.files?.[0] || null)} />
        <Button type="submit" disabled={uploading} className="w-full gap-2"><Upload size={18} />{uploading ? "Uploading..." : "Upload"}</Button>
      </form>
      <div>
        <h2 className="text-lg font-bold text-foreground mb-4">📚 All Materials ({materials.length})</h2>
        {materials.length === 0 ? <p className="text-muted-foreground text-center py-10">No materials yet.</p> : (
          <div className="space-y-3">
            {materials.map(m => (
              <div key={m.id} className="bg-card p-4 rounded-xl border border-border flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="font-bold text-foreground text-sm">{m.title}</p>
                  <p className="text-xs text-muted-foreground">Class {m.class_number} • {m.category.replace("-", " ")}</p>
                </div>
                <div className="flex gap-1">
                  <a href={m.file_url} target="_blank" rel="noopener noreferrer"><Button variant="outline" size="sm">View</Button></a>
                  <Button variant="destructive" size="sm" onClick={() => handleDelete(m)}><Trash2 size={14} /></Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Admin;
