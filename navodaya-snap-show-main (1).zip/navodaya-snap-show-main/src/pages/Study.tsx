import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { FileText, Download, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Material {
  id: string;
  title: string;
  class_number: number;
  category: string;
  file_url: string;
  created_at: string;
}

const classes = [6, 7, 8, 9, 10, 11, 12];

const Study = () => {
  const [materials, setMaterials] = useState<Material[]>([]);
  const [selectedClass, setSelectedClass] = useState(6);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      const { data } = await supabase
        .from("study_materials")
        .select("*")
        .order("created_at", { ascending: false });
      if (data) setMaterials(data);
      setLoading(false);
    };
    fetch();
  }, []);

  const filtered = materials.filter((m) => m.class_number === selectedClass);

  const categoryColors: Record<string, string> = {
    syllabus: "bg-school-blue/10 text-school-blue",
    "previous-papers": "bg-school-orange/10 text-school-orange",
    "study-guide": "bg-school-green/10 text-school-green",
    general: "bg-school-purple/10 text-school-purple",
  };

  return (
    <div className="min-h-screen">
      <Navbar />
      <div className="pt-20 pb-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-10">
            <h1 className="text-3xl sm:text-4xl font-black text-foreground">
              📚 <span className="text-school-blue">Study</span>{" "}
              <span className="text-school-orange">Materials</span>
            </h1>
            <p className="text-muted-foreground mt-2 font-medium">
              Download syllabus, previous year papers & study guides — class-wise
            </p>
          </div>

          {/* Class selector */}
          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {classes.map((c) => (
              <button
                key={c}
                onClick={() => setSelectedClass(c)}
                className={`px-5 py-2.5 rounded-full font-bold text-sm transition-all ${
                  selectedClass === c
                    ? "bg-primary text-primary-foreground shadow-lg scale-105"
                    : "bg-card border border-border text-foreground hover:bg-muted"
                }`}
              >
                Class {c}
              </button>
            ))}
          </div>

          {/* Materials list */}
          {loading ? (
            <p className="text-center text-muted-foreground py-16">Loading...</p>
          ) : filtered.length === 0 ? (
            <div className="text-center py-16">
              <BookOpen className="mx-auto w-16 h-16 text-muted-foreground/40 mb-4" />
              <p className="text-muted-foreground font-medium">
                No materials uploaded for Class {selectedClass} yet.
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                Check back later or ask your teacher!
              </p>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filtered.map((m) => (
                <div
                  key={m.id}
                  className="bg-card rounded-2xl border border-border p-5 shadow-md hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-start gap-3">
                    <div className="p-2 rounded-xl bg-school-blue/10">
                      <FileText className="text-school-blue w-6 h-6" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-foreground text-sm truncate">{m.title}</h3>
                      <span
                        className={`inline-block mt-1 px-2 py-0.5 rounded-full text-xs font-semibold ${
                          categoryColors[m.category] || categoryColors.general
                        }`}
                      >
                        {m.category.replace("-", " ")}
                      </span>
                    </div>
                  </div>
                  <a href={m.file_url} target="_blank" rel="noopener noreferrer">
                    <Button size="sm" className="w-full mt-4 gap-2">
                      <Download size={14} /> Download
                    </Button>
                  </a>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Study;
