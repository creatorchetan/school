import { useState } from "react";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import NoticeBoardTicker from "@/components/NoticeBoardTicker";
import PhotoSlideshow from "@/components/PhotoSlideshow";
import AchievementsSection from "@/components/AchievementsSection";
import VideosSection from "@/components/VideosSection";
import AboutSection from "@/components/AboutSection";
import StaffMessagesSection from "@/components/StaffMessagesSection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";
import SchoolShowcase from "@/components/SchoolShowcase";
import { Play } from "lucide-react";

const Index = () => {
  const [showcaseOpen, setShowcaseOpen] = useState(false);

  return (
    <div className="min-h-screen">
      <Navbar />
      <HeroSection />
      <NoticeBoardTicker />

      {/* Showcase button */}
      <div className="text-center py-4 bg-background">
        <button
          onClick={() => setShowcaseOpen(true)}
          className="inline-flex items-center gap-2 bg-gradient-to-r from-school-blue to-school-purple text-white font-bold px-6 py-3 rounded-full shadow-lg hover:shadow-xl hover:scale-105 transition-all"
        >
          <Play size={18} fill="currentColor" /> Play School Showcase
        </button>
      </div>

      <PhotoSlideshow />
      <AchievementsSection />
      <VideosSection />
      <AboutSection />
      <StaffMessagesSection />
      <ContactSection />
      <Footer />

      {showcaseOpen && <SchoolShowcase onClose={() => setShowcaseOpen(false)} />}
    </div>
  );
};

export default Index;
