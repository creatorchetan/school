import { useEffect, useState, useCallback } from "react";
import { X, ChevronLeft, ChevronRight, Pause, Play } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface Slide {
  type: "photo" | "achievement";
  title: string;
  imageUrl?: string;
  description?: string;
  year?: string;
  color?: string;
}

interface SchoolShowcaseProps {
  onClose: () => void;
}

const SchoolShowcase = ({ onClose }: SchoolShowcaseProps) => {
  const [slides, setSlides] = useState<Slide[]>([]);
  const [current, setCurrent] = useState(0);
  const [playing, setPlaying] = useState(true);

  useEffect(() => {
    const fetchSlides = async () => {
      const [photosRes, achievementsRes] = await Promise.all([
        supabase.from("school_photos").select("*").order("display_order"),
        supabase.from("school_achievements").select("*").order("display_order"),
      ]);

      const all: Slide[] = [];
      photosRes.data?.forEach((p) =>
        all.push({ type: "photo", title: p.title, imageUrl: p.image_url })
      );
      achievementsRes.data?.forEach((a) =>
        all.push({
          type: "achievement",
          title: a.title,
          description: a.description,
          year: a.year,
          color: a.color_theme,
        })
      );
      if (all.length === 0) {
        all.push({ type: "achievement", title: "No content yet", description: "Add photos and achievements from the admin panel." });
      }
      setSlides(all);
    };
    fetchSlides();
  }, []);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") setCurrent((c) => (c + 1) % slides.length);
      if (e.key === "ArrowLeft") setCurrent((c) => (c - 1 + slides.length) % slides.length);
      if (e.key === " ") { e.preventDefault(); setPlaying((p) => !p); }
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [onClose, slides.length]);

  useEffect(() => {
    if (!playing || slides.length <= 1) return;
    const timer = setInterval(() => setCurrent((c) => (c + 1) % slides.length), 4000);
    return () => clearInterval(timer);
  }, [playing, slides.length]);

  const slide = slides[current];
  if (!slide) return null;

  const colorMap: Record<string, string> = {
    blue: "from-blue-500 to-blue-700",
    green: "from-green-500 to-green-700",
    orange: "from-orange-500 to-orange-700",
    yellow: "from-yellow-400 to-yellow-600",
    purple: "from-purple-500 to-purple-700",
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black flex flex-col">
      {/* Top bar */}
      <div className="absolute top-0 left-0 right-0 z-10 flex items-center justify-between p-4 bg-gradient-to-b from-black/60 to-transparent">
        <span className="text-white/80 text-sm font-semibold">
          {current + 1} / {slides.length}
        </span>
        <div className="flex gap-2">
          <button onClick={() => setPlaying(!playing)} className="p-2 rounded-full bg-white/20 hover:bg-white/30 text-white">
            {playing ? <Pause size={18} /> : <Play size={18} />}
          </button>
          <button onClick={onClose} className="p-2 rounded-full bg-white/20 hover:bg-white/30 text-white">
            <X size={18} />
          </button>
        </div>
      </div>

      {/* Slide content */}
      <div className="flex-1 flex items-center justify-center p-8">
        {slide.type === "photo" ? (
          <div className="text-center max-w-4xl">
            <img
              src={slide.imageUrl}
              alt={slide.title}
              className="max-h-[70vh] mx-auto rounded-2xl shadow-2xl object-contain"
            />
            <h2 className="text-white text-2xl font-bold mt-4">{slide.title}</h2>
          </div>
        ) : (
          <div className={`max-w-lg w-full rounded-3xl p-10 text-center bg-gradient-to-br ${colorMap[slide.color || "blue"] || colorMap.blue} shadow-2xl`}>
            <span className="text-6xl">🏆</span>
            <h2 className="text-white text-3xl font-black mt-4">{slide.title}</h2>
            {slide.description && <p className="text-white/90 mt-3 text-lg">{slide.description}</p>}
            {slide.year && <p className="text-white/70 mt-2 font-semibold">{slide.year}</p>}
          </div>
        )}
      </div>

      {/* Navigation */}
      {slides.length > 1 && (
        <>
          <button
            onClick={() => setCurrent((c) => (c - 1 + slides.length) % slides.length)}
            className="absolute left-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-white/20 hover:bg-white/30 text-white"
          >
            <ChevronLeft size={24} />
          </button>
          <button
            onClick={() => setCurrent((c) => (c + 1) % slides.length)}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-white/20 hover:bg-white/30 text-white"
          >
            <ChevronRight size={24} />
          </button>
        </>
      )}

      {/* Progress dots */}
      <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-1.5">
        {slides.slice(0, 20).map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrent(i)}
            className={`w-2 h-2 rounded-full transition-all ${i === current ? "bg-white w-6" : "bg-white/40"}`}
          />
        ))}
        {slides.length > 20 && <span className="text-white/40 text-xs ml-1">+{slides.length - 20}</span>}
      </div>
    </div>
  );
};

export default SchoolShowcase;
