import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Megaphone } from "lucide-react";

const NoticeBoardTicker = () => {
  const [notices, setNotices] = useState<{ id: string; text: string }[]>([]);

  useEffect(() => {
    const fetch = async () => {
      const { data } = await supabase
        .from("notices")
        .select("id, text")
        .eq("active", true)
        .order("created_at", { ascending: false });
      if (data) setNotices(data);
    };
    fetch();
  }, []);

  if (notices.length === 0) return null;

  const tickerText = notices.map((n) => n.text).join("   •   ");

  return (
    <div className="bg-school-yellow text-foreground py-2 overflow-hidden relative">
      <div className="flex items-center">
        <span className="flex-shrink-0 bg-school-orange text-white px-3 py-1 rounded-r-full font-bold text-xs flex items-center gap-1 z-10">
          <Megaphone size={14} /> NOTICE
        </span>
        <div className="overflow-hidden flex-1 ml-2">
          <div className="animate-ticker whitespace-nowrap font-semibold text-sm">
            {tickerText}   •   {tickerText}
          </div>
        </div>
      </div>
    </div>
  );
};

export default NoticeBoardTicker;
