import { useState } from "react";
import { Send, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

const ContactSection = () => {
  const { toast } = useToast();
  const [submitted, setSubmitted] = useState(false);
  const [sending, setSending] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) {
      toast({ title: "Please fill all required fields", variant: "destructive" });
      return;
    }
    setSending(true);
    const { error } = await supabase.from("contact_messages").insert({
      name: form.name.trim(),
      email: form.email.trim(),
      subject: form.subject.trim(),
      message: form.message.trim(),
    });
    setSending(false);
    if (error) {
      toast({ title: "Failed to send", description: error.message, variant: "destructive" });
      return;
    }
    setSubmitted(true);
    toast({ title: "Message sent!", description: "We'll get back to you soon." });
  };

  return (
    <section id="contact" className="py-16">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-3xl sm:text-4xl font-black text-foreground text-center">
          ✉️ <span className="text-school-blue">Contact</span>{" "}
          <span className="text-school-orange">Us</span>
        </h2>
        <p className="text-center text-muted-foreground mt-2 font-medium">
          Have a question? Send us a message and we'll reply soon!
        </p>

        <div className="max-w-xl mx-auto mt-10">
          {submitted ? (
            <div className="text-center py-16 rounded-2xl bg-card border border-border shadow-md">
              <CheckCircle className="w-16 h-16 text-school-green mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-foreground">Thank You!</h3>
              <p className="text-muted-foreground mt-2">Your message has been received. We'll get back to you shortly.</p>
              <Button className="mt-6" onClick={() => { setSubmitted(false); setForm({ name: "", email: "", subject: "", message: "" }); }}>
                Send Another Message
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="rounded-2xl bg-card border border-border shadow-md p-6 sm:p-8 space-y-5">
              <div>
                <label className="text-sm font-bold text-foreground">Name *</label>
                <Input placeholder="Your full name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="mt-1" maxLength={100} />
              </div>
              <div>
                <label className="text-sm font-bold text-foreground">Email *</label>
                <Input type="email" placeholder="your@email.com" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="mt-1" maxLength={255} />
              </div>
              <div>
                <label className="text-sm font-bold text-foreground">Subject</label>
                <Input placeholder="What is this about?" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} className="mt-1" maxLength={200} />
              </div>
              <div>
                <label className="text-sm font-bold text-foreground">Message *</label>
                <Textarea placeholder="Write your message here..." value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} className="mt-1 min-h-[120px]" maxLength={1000} />
              </div>
              <Button type="submit" disabled={sending} className="w-full gap-2 bg-school-blue hover:bg-school-blue/90 text-white font-bold">
                <Send size={18} />
                {sending ? "Sending..." : "Send Message"}
              </Button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
