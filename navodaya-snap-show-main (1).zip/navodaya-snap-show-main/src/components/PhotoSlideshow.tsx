import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

const fallbackPhotos = [
  { src: "https://images.unsplash.com/photo-1580582932707-520aed937b7b?w=800&h=500&fit=crop", alt: "School Building" },
  { src: "https://images.unsplash.com/photo-1523050854058-8df90110c476?w=800&h=500&fit=crop", alt: "School Sports Day" },
  { src: "https://images.unsplash.com/photo-1577896851231-70ef18881754?w=800&h=500&fit=crop", alt: "Classroom Learning" },
  { src: "https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?w=800&h=500&fit=crop", alt: "Students Together" },
  { src: "https://images.unsplash.com/photo-1509062522246-3755977927d7?w=800&h=500&fit=crop", alt: "Cultural Program" },
  { src: "https://images.unsplash.com/photo-1544717305-2782549b5136?w=800&h=500&fit=crop", alt: "Library" },
];

const PhotoSlideshow = () => {
  const [photos, setPhotos] = useState<{ src: string; alt: string }[]>([]);

  useEffect(() => {
    const fetchPhotos = async () => {
      const { data } = await supabase
        .from("school_photos")
        .select("*")
        .order("created_at", { ascending: false });

      if (data && data.length > 0) {
        setPhotos(data.map(p => ({ src: p.image_url, alt: p.title })));
      } else {
        setPhotos(fallbackPhotos);
      }
    };
    fetchPhotos();
  }, []);

  const slides = [...photos, ...photos];

  if (photos.length === 0) return null;

  return (
    <section id="gallery" className="py-16 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 mb-10">
        <h2 className="text-3xl sm:text-4xl font-black text-foreground text-center">
          📸 Our <span className="text-school-blue">School</span>{" "}
          <span className="text-school-orange">Gallery</span>
        </h2>
        <p className="text-center text-muted-foreground mt-2 font-medium">
          Memories that make us proud — hover to pause!
        </p>
      </div>

      <div className="relative">
        <div className="flex animate-scroll-slide gap-4 w-max">
          {slides.map((photo, i) => (
            <div
              key={i}
              className="w-72 sm:w-80 h-48 sm:h-56 rounded-2xl overflow-hidden shadow-lg flex-shrink-0 group"
            >
              <img
                src={photo.src}
                alt={photo.alt}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                loading="lazy"
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PhotoSlideshow;
