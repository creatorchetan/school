import { Users, BookOpen, Home, Leaf } from "lucide-react";
import { useSiteContent } from "@/hooks/useSiteContent";

const iconMap: Record<string, any> = { Users, BookOpen, Home, Leaf };

const AboutSection = () => {
  const { get } = useSiteContent();

  const stats = [
    { icon: Users, value: get("stats_students", "500+"), label: "Students", color: "text-school-blue" },
    { icon: BookOpen, value: get("stats_teachers", "40+"), label: "Teachers", color: "text-school-orange" },
    { icon: Home, value: get("stats_classrooms", "30+"), label: "Classrooms", color: "text-school-green" },
    { icon: Leaf, value: get("stats_campus", "10 Acres"), label: "Green Campus", color: "text-school-purple" },
  ];

  return (
    <section id="about" className="py-16 bg-muted/50">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-3xl sm:text-4xl font-black text-foreground text-center">
          🏫 About <span className="text-school-green">Our School</span>
        </h2>

        <div className="mt-10 grid lg:grid-cols-2 gap-10 items-start">
          <div className="space-y-6">
            <div className="rounded-2xl bg-card p-6 shadow-md border border-border">
              <h3 className="text-xl font-bold text-foreground flex items-center gap-2">📖 Our History</h3>
              <p className="text-muted-foreground mt-2 leading-relaxed">
                {get("school_history", "Jawahar Navodaya Vidyalaya Buklana, Bulandshahr is a central government-funded residential school in India for talented students from rural areas. Established under the National Policy of Education 1986, JNVs provide quality education to gifted children from Class VI to XII, irrespective of their family's socio-economic condition.")}
              </p>
            </div>

            <div className="rounded-2xl bg-card p-6 shadow-md border border-border">
              <h3 className="text-xl font-bold text-foreground flex items-center gap-2">🎯 Vision & Mission</h3>
              <p className="text-muted-foreground mt-2 leading-relaxed">
                {get("vision_mission", "To provide good quality modern education including a strong component of culture, inculcation of values, awareness of the environment, adventure activities and physical education to talented children from rural areas.")}
              </p>
            </div>

            <div className="rounded-2xl bg-card p-6 shadow-md border border-border">
              <h3 className="text-xl font-bold text-foreground flex items-center gap-2">💬 Principal's Message</h3>
              <p className="text-muted-foreground mt-2 leading-relaxed italic">
                {get("principal_message", '"Our school believes in nurturing every child\'s potential. We focus on holistic development — academics, sports, culture, and values. Together, we aim to create responsible citizens who contribute positively to society."')}
              </p>
              <p className="text-sm font-bold text-foreground mt-2">
                {get("principal_name", "— The Principal, JNV")}
              </p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              {stats.map((stat, i) => {
                const Icon = stat.icon;
                return (
                  <div key={i} className="rounded-2xl bg-card p-5 shadow-md border border-border text-center hover:scale-105 transition-transform">
                    <Icon className={`w-8 h-8 mx-auto mb-2 ${stat.color}`} />
                    <div className="text-2xl font-black text-foreground">{stat.value}</div>
                    <div className="text-sm text-muted-foreground font-medium">{stat.label}</div>
                  </div>
                );
              })}
            </div>

            <div className="rounded-2xl overflow-hidden shadow-lg">
              <img
                src="https://images.unsplash.com/photo-1562774053-701939374585?w=800&h=500&fit=crop"
                alt="School Campus"
                className="w-full h-64 object-cover"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
