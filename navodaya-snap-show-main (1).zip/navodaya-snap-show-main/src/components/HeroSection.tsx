import { useSiteContent } from "@/hooks/useSiteContent";
import { ChevronDown } from "lucide-react";

const HeroSection = () => {
  const { get } = useSiteContent();

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
      style={{
        background:
          "linear-gradient(135deg, hsl(217 91% 60%) 0%, hsl(262 83% 58%) 40%, hsl(25 95% 53%) 80%, hsl(48 96% 53%) 100%)",
      }}
    >
      <div className="absolute top-10 left-10 w-32 h-32 rounded-full bg-white/10 blur-2xl" />
      <div className="absolute bottom-20 right-10 w-48 h-48 rounded-full bg-white/10 blur-3xl" />
      <div className="absolute top-1/3 right-1/4 w-24 h-24 rounded-full bg-white/5 blur-xl" />

      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <div className="mx-auto mb-6 w-24 h-24 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center border-2 border-white/40">
          <span className="text-4xl font-black text-white">JNV</span>
        </div>

        <h1 className="text-4xl sm:text-5xl md:text-7xl font-black text-white drop-shadow-lg leading-tight">
          Jawahar Navodaya
          <br />
          Vidyalaya
        </h1>

        <p className="mt-2 text-xl sm:text-2xl font-bold text-white/90">
          Buklana, Bulandshahr
        </p>

        <p className="mt-4 text-lg sm:text-xl text-white/90 font-semibold max-w-2xl mx-auto">
          {get("hero_motto", '"प्रज्ञानं ब्रह्म" — Nurturing talent from rural India since 1986')}
        </p>

        <p className="mt-2 text-white/70 font-medium">
          A Centre of Excellence in Education
        </p>

        <a
          href="#gallery"
          className="mt-8 inline-flex items-center gap-2 bg-white text-primary font-bold px-8 py-3 rounded-full shadow-lg hover:shadow-xl hover:scale-105 transition-all"
        >
          Explore Our School
          <ChevronDown size={20} />
        </a>
      </div>

      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 100" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M0 40C360 80 720 0 1080 40C1260 60 1380 80 1440 80V100H0V40Z"
            fill="hsl(40 33% 98%)"
          />
        </svg>
      </div>
    </section>
  );
};

export default HeroSection;
