import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { User } from "lucide-react";

interface StaffMessage {
  id: string;
  name: string;
  role: string;
  message: string;
  photo_url: string;
  display_order: number;
}

const StaffMessagesSection = () => {
  const [staff, setStaff] = useState<StaffMessage[]>([]);

  useEffect(() => {
    const fetch = async () => {
      const { data } = await supabase
        .from("staff_messages")
        .select("*")
        .order("display_order");
      if (data) setStaff(data);
    };
    fetch();
  }, []);

  if (staff.length === 0) return null;

  return (
    <section id="staff" className="py-16 bg-muted/50">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-3xl sm:text-4xl font-black text-foreground text-center">
          👨‍🏫 Messages from <span className="text-school-purple">Our Leaders</span>
        </h2>
        <p className="text-center text-muted-foreground mt-2 font-medium">
          Words of wisdom from our school leaders and staff
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mt-10">
          {staff.map((s) => (
            <div
              key={s.id}
              className="bg-card rounded-2xl border border-border shadow-md p-6 hover:shadow-lg transition-shadow"
            >
              <div className="flex items-center gap-4 mb-4">
                {s.photo_url ? (
                  <img
                    src={s.photo_url}
                    alt={s.name}
                    className="w-16 h-16 rounded-full object-cover border-2 border-primary/30"
                  />
                ) : (
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center border-2 border-primary/30">
                    <User className="w-8 h-8 text-primary" />
                  </div>
                )}
                <div>
                  <h3 className="font-bold text-foreground">{s.name}</h3>
                  <p className="text-sm text-primary font-semibold">{s.role}</p>
                </div>
              </div>
              <p className="text-muted-foreground text-sm leading-relaxed italic">
                "{s.message}"
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StaffMessagesSection;
