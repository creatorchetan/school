import { MapPin, Phone, Mail } from "lucide-react";
import { useSiteContent } from "@/hooks/useSiteContent";
import { useNavigate, useLocation } from "react-router-dom";

const Footer = () => {
  const { get } = useSiteContent();
  const navigate = useNavigate();
  const location = useLocation();

  const handleQuickLink = (e: React.MouseEvent<HTMLAnchorElement>, hash: string) => {
    e.preventDefault();
    if (location.pathname !== "/") {
      navigate("/");
      setTimeout(() => {
        const el = document.getElementById(hash);
        if (el) el.scrollIntoView({ behavior: "smooth" });
      }, 100);
    } else {
      const el = document.getElementById(hash);
      if (el) el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer
      className="py-12 text-white"
      style={{
        background:
          "linear-gradient(135deg, hsl(217 91% 30%) 0%, hsl(262 83% 35%) 100%)",
      }}
    >
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          <div>
            <h3 className="text-2xl font-black mb-4">JNV</h3>
            <p className="text-white/70 text-sm leading-relaxed">
              Jawahar Navodaya Vidyalaya Buklana, Bulandshahr — A Centre of Excellence providing
              quality education to talented rural students.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-lg mb-4">Contact Us</h4>
            <div className="space-y-3 text-sm text-white/80">
              <div className="flex items-start gap-2">
                <MapPin size={16} className="mt-0.5 flex-shrink-0" />
                <span>{get("contact_address", "Jawahar Navodaya Vidyalaya, Buklana, Bulandshahr, Uttar Pradesh")}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone size={16} className="flex-shrink-0" />
                <span>{get("contact_phone", "+91 XXXXX XXXXX")}</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail size={16} className="flex-shrink-0" />
                <span>{get("contact_email", "jnv.school@example.com")}</span>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-bold text-lg mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm text-white/80">
              <li><a href="/#home" onClick={(e) => handleQuickLink(e, "home")} className="hover:text-white transition-colors">Home</a></li>
              <li><a href="/#gallery" onClick={(e) => handleQuickLink(e, "gallery")} className="hover:text-white transition-colors">Gallery</a></li>
              <li><a href="/#achievements" onClick={(e) => handleQuickLink(e, "achievements")} className="hover:text-white transition-colors">Achievements</a></li>
              <li><a href="/#videos" onClick={(e) => handleQuickLink(e, "videos")} className="hover:text-white transition-colors">Videos</a></li>
              <li><a href="/#about" onClick={(e) => handleQuickLink(e, "about")} className="hover:text-white transition-colors">About</a></li>
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-white/20 text-center text-sm text-white/60">
          <p>Made with ❤️ by <span className="font-bold text-white/80">Chetan Raj Singh</span> — Class 12 A (Bio)</p>
          <p className="mt-1">© {new Date().getFullYear()} JNV Buklana, Bulandshahr. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
