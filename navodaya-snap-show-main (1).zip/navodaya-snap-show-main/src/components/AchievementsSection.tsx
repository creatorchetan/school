import { Trophy, Medal, Star, Award } from "lucide-react";
import { useAchievements } from "@/hooks/useAchievements";

const iconMap: Record<string, any> = { Trophy, Medal, Star, Award };
const colorMap: Record<string, { bg: string; icon: string }> = {
  yellow: { bg: "bg-school-yellow/15 text-school-yellow border-school-yellow/30", icon: "text-school-yellow" },
  green: { bg: "bg-school-green/15 text-school-green border-school-green/30", icon: "text-school-green" },
  blue: { bg: "bg-school-blue/15 text-school-blue border-school-blue/30", icon: "text-school-blue" },
  orange: { bg: "bg-school-orange/15 text-school-orange border-school-orange/30", icon: "text-school-orange" },
  purple: { bg: "bg-school-purple/15 text-school-purple border-school-purple/30", icon: "text-school-purple" },
};

const AchievementsSection = () => {
  const { achievements } = useAchievements();

  return (
    <section id="achievements" className="py-16 bg-muted/50">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-3xl sm:text-4xl font-black text-foreground text-center">
          🏆 Our <span className="text-school-orange">Achievements</span>
        </h2>
        <p className="text-center text-muted-foreground mt-2 font-medium">
          Proudly showcasing what our students and school have accomplished
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-10">
          {achievements.map((item, i) => {
            const Icon = iconMap[item.icon_name] || Trophy;
            const colors = colorMap[item.color_theme] || colorMap.blue;
            return (
              <div
                key={item.id}
                className={`rounded-2xl border-2 p-6 ${colors.bg} hover:scale-[1.03] transition-transform duration-300 cursor-default`}
              >
                <div className="flex items-center gap-3 mb-3">
                  <Icon className={`w-8 h-8 ${colors.icon}`} />
                  <span className="text-xs font-bold bg-foreground/10 px-2 py-1 rounded-full">{item.year}</span>
                </div>
                <h3 className="text-lg font-bold text-foreground">{item.title}</h3>
                <p className="text-sm text-muted-foreground mt-1">{item.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default AchievementsSection;
