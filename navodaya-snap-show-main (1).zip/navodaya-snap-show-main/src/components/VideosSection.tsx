import { useState, useEffect } from "react";
import { Play, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface Video {
  id: string;
  title: string;
  video_type: string;
  video_url: string;
  thumbnail_url: string;
}

const fallbackVideos = [
  {
    id: "demo1",
    title: "Annual Day Celebration 2024",
    thumbnail_url: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=600&h=340&fit=crop",
    video_type: "youtube",
    video_url: "https://www.youtube.com/embed/dQw4w9WgXcQ",
  },
  {
    id: "demo2",
    title: "Republic Day Parade",
    thumbnail_url: "https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=600&h=340&fit=crop",
    video_type: "youtube",
    video_url: "https://www.youtube.com/embed/dQw4w9WgXcQ",
  },
];

const VideosSection = () => {
  const [videos, setVideos] = useState<Video[]>([]);
  const [activeVideo, setActiveVideo] = useState<{ url: string; type: string } | null>(null);

  useEffect(() => {
    const fetch = async () => {
      const { data } = await supabase
        .from("school_videos")
        .select("*")
        .order("display_order");
      if (data && data.length > 0) {
        setVideos(data);
      } else {
        setVideos(fallbackVideos as any);
      }
    };
    fetch();
  }, []);

  const getYouTubeEmbedUrl = (url: string) => {
    // Convert various YouTube URL formats to embed
    const match = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([a-zA-Z0-9_-]+)/);
    if (match) return `https://www.youtube.com/embed/${match[1]}`;
    return url;
  };

  const getThumbnail = (video: Video) => {
    if (video.thumbnail_url) return video.thumbnail_url;
    // Auto-generate YouTube thumbnail
    const match = video.video_url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([a-zA-Z0-9_-]+)/);
    if (match) return `https://img.youtube.com/vi/${match[1]}/hqdefault.jpg`;
    return "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=600&h=340&fit=crop";
  };

  return (
    <section id="videos" className="py-16">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-3xl sm:text-4xl font-black text-foreground text-center">
          🎬 School <span className="text-school-purple">Videos</span>
        </h2>
        <p className="text-center text-muted-foreground mt-2 font-medium">
          Watch our best moments come alive
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mt-10">
          {videos.map((video) => (
            <div
              key={video.id}
              className="group relative rounded-2xl overflow-hidden shadow-lg cursor-pointer hover:shadow-xl transition-shadow"
              onClick={() => setActiveVideo({ url: video.video_url, type: video.video_type })}
            >
              <img
                src={getThumbnail(video)}
                alt={video.title}
                className="w-full h-48 sm:h-56 object-cover group-hover:scale-105 transition-transform duration-500"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-foreground/30 flex items-center justify-center group-hover:bg-foreground/40 transition-colors">
                <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                  <Play className="text-primary-foreground w-7 h-7 ml-1" fill="currentColor" />
                </div>
              </div>
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-foreground/80 to-transparent p-4">
                <h3 className="text-white font-bold text-sm">{video.title}</h3>
                <span className="text-white/70 text-xs uppercase">{video.video_type}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Video Modal */}
      {activeVideo && (
        <div
          className="fixed inset-0 z-50 bg-foreground/80 flex items-center justify-center p-4"
          onClick={() => setActiveVideo(null)}
        >
          <div
            className="relative w-full max-w-3xl aspect-video bg-black rounded-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {activeVideo.type === "youtube" ? (
              <iframe
                src={getYouTubeEmbedUrl(activeVideo.url) + "?autoplay=1"}
                className="w-full h-full"
                allow="autoplay; encrypted-media"
                allowFullScreen
                title="School Video"
              />
            ) : (
              <video
                src={activeVideo.url}
                className="w-full h-full"
                controls
                autoPlay
              />
            )}
            <button
              className="absolute top-3 right-3 bg-white/20 backdrop-blur-sm rounded-full p-2 hover:bg-white/40 transition-colors"
              onClick={() => setActiveVideo(null)}
            >
              <X className="text-white w-5 h-5" />
            </button>
          </div>
        </div>
      )}
    </section>
  );
};

export default VideosSection;
