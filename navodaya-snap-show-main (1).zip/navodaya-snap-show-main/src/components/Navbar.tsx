import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Menu, X } from "lucide-react";

const navLinks = [
  { label: "Home", href: "/#home" },
  { label: "Gallery", href: "/#gallery" },
  { label: "Achievements", href: "/#achievements" },
  { label: "Videos", href: "/#videos" },
  { label: "About", href: "/#about" },
  { label: "Study", href: "/study" },
  { label: "Contact", href: "/#contact" },
];

const Navbar = () => {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setOpen(false);

    if (href === "/study") {
      navigate("/study");
      return;
    }

    // Extract hash
    const hash = href.includes("#") ? href.split("#")[1] : "";
    
    if (location.pathname !== "/") {
      // Navigate to home first, then scroll
      navigate("/");
      setTimeout(() => {
        const el = document.getElementById(hash);
        if (el) el.scrollIntoView({ behavior: "smooth" });
      }, 100);
    } else {
      const el = document.getElementById(hash);
      if (el) el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-card/90 backdrop-blur-md shadow-md">
      <div className="max-w-7xl mx-auto px-4 flex items-center justify-between h-16">
        <a href="/#home" onClick={(e) => handleNavClick(e, "/#home")} className="flex items-center gap-2">
          <span className="text-2xl font-black text-gradient">JNV</span>
          <span className="hidden sm:inline font-bold text-foreground text-sm">
            JNV Buklana, Bulandshahr
          </span>
        </a>

        <ul className="hidden md:flex gap-1">
          {navLinks.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="px-4 py-2 rounded-lg font-semibold text-foreground/80 hover:text-primary hover:bg-primary/10 transition-colors"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <button
          className="md:hidden p-2 rounded-lg hover:bg-muted"
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {open && (
        <div className="md:hidden bg-card border-t border-border px-4 pb-4">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="block py-3 font-semibold text-foreground/80 hover:text-primary transition-colors"
              onClick={(e) => handleNavClick(e, link.href)}
            >
              {link.label}
            </a>
          ))}
        </div>
      )}
    </nav>
  );
};

export default Navbar;
