import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface Achievement {
  id: string;
  title: string;
  description: string;
  year: string;
  icon_name: string;
  color_theme: string;
  display_order: number;
}

const defaultAchievements: Achievement[] = [
  { id: "1", title: "100% Board Results", description: "All students passed Class X & XII board exams with distinction.", year: "2024", icon_name: "Trophy", color_theme: "yellow", display_order: 0 },
  { id: "2", title: "State Sports Champions", description: "Won 12 gold medals in inter-school state-level sports competition.", year: "2024", icon_name: "Medal", color_theme: "green", display_order: 1 },
  { id: "3", title: "Science Olympiad Winners", description: "3 students selected for National Science Olympiad finals.", year: "2023", icon_name: "Star", color_theme: "blue", display_order: 2 },
  { id: "4", title: "Cultural Fest — 1st Prize", description: "Bagged overall championship in Regional Cultural Festival.", year: "2023", icon_name: "Award", color_theme: "orange", display_order: 3 },
  { id: "5", title: "Clean School Award", description: "Awarded Swachh Vidyalaya Puraskar by the Government of India.", year: "2023", icon_name: "Trophy", color_theme: "purple", display_order: 4 },
  { id: "6", title: "JEE / NEET Qualifiers", description: "15 students qualified JEE Mains and 8 qualified NEET in one year.", year: "2024", icon_name: "Star", color_theme: "blue", display_order: 5 },
];

export const useAchievements = () => {
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [loading, setLoading] = useState(true);

  const fetch = async () => {
    const { data } = await supabase
      .from("school_achievements")
      .select("*")
      .order("display_order", { ascending: true });
    setAchievements(data && data.length > 0 ? data : defaultAchievements);
    setLoading(false);
  };

  useEffect(() => { fetch(); }, []);

  return { achievements, loading, refetch: fetch };
};
