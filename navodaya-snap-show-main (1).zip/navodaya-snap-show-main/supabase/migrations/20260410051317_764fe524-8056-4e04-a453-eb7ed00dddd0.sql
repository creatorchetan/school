
-- 1. Create admins table
CREATE TABLE public.admins (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE
);
ALTER TABLE public.admins ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view admins" ON public.admins FOR SELECT TO authenticated USING (true);

-- 2. Security definer function to check admin status
CREATE OR REPLACE FUNCTION public.is_admin(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM public.admins WHERE user_id = _user_id)
$$;

-- 3. Fix notices SELECT: public sees only active, admins see all
DROP POLICY "Anyone can view active notices" ON public.notices;
CREATE POLICY "Public can view active notices" ON public.notices FOR SELECT TO public USING (active = true);
CREATE POLICY "Admins can view all notices" ON public.notices FOR SELECT TO authenticated USING (public.is_admin(auth.uid()));

-- 4. Replace all write policies on notices
DROP POLICY "Authenticated users can insert notices" ON public.notices;
DROP POLICY "Authenticated users can update notices" ON public.notices;
DROP POLICY "Authenticated users can delete notices" ON public.notices;
CREATE POLICY "Admins can insert notices" ON public.notices FOR INSERT TO authenticated WITH CHECK (public.is_admin(auth.uid()));
CREATE POLICY "Admins can update notices" ON public.notices FOR UPDATE TO authenticated USING (public.is_admin(auth.uid()));
CREATE POLICY "Admins can delete notices" ON public.notices FOR DELETE TO authenticated USING (public.is_admin(auth.uid()));

-- 5. Replace all write policies on school_achievements
DROP POLICY "Authenticated users can insert achievements" ON public.school_achievements;
DROP POLICY "Authenticated users can update achievements" ON public.school_achievements;
DROP POLICY "Authenticated users can delete achievements" ON public.school_achievements;
CREATE POLICY "Admins can insert achievements" ON public.school_achievements FOR INSERT TO authenticated WITH CHECK (public.is_admin(auth.uid()));
CREATE POLICY "Admins can update achievements" ON public.school_achievements FOR UPDATE TO authenticated USING (public.is_admin(auth.uid()));
CREATE POLICY "Admins can delete achievements" ON public.school_achievements FOR DELETE TO authenticated USING (public.is_admin(auth.uid()));

-- 6. Replace all write policies on school_photos + add missing UPDATE
DROP POLICY "Authenticated users can insert photos" ON public.school_photos;
DROP POLICY "Authenticated users can delete photos" ON public.school_photos;
CREATE POLICY "Admins can insert photos" ON public.school_photos FOR INSERT TO authenticated WITH CHECK (public.is_admin(auth.uid()));
CREATE POLICY "Admins can update photos" ON public.school_photos FOR UPDATE TO authenticated USING (public.is_admin(auth.uid()));
CREATE POLICY "Admins can delete photos" ON public.school_photos FOR DELETE TO authenticated USING (public.is_admin(auth.uid()));

-- 7. Replace all write policies on site_content
DROP POLICY "Authenticated users can insert content" ON public.site_content;
DROP POLICY "Authenticated users can update content" ON public.site_content;
DROP POLICY "Authenticated users can delete content" ON public.site_content;
CREATE POLICY "Admins can insert content" ON public.site_content FOR INSERT TO authenticated WITH CHECK (public.is_admin(auth.uid()));
CREATE POLICY "Admins can update content" ON public.site_content FOR UPDATE TO authenticated USING (public.is_admin(auth.uid()));
CREATE POLICY "Admins can delete content" ON public.site_content FOR DELETE TO authenticated USING (public.is_admin(auth.uid()));

-- 8. Replace all write policies on study_materials + add missing UPDATE
DROP POLICY "Authenticated users can insert materials" ON public.study_materials;
DROP POLICY "Authenticated users can delete materials" ON public.study_materials;
CREATE POLICY "Admins can insert materials" ON public.study_materials FOR INSERT TO authenticated WITH CHECK (public.is_admin(auth.uid()));
CREATE POLICY "Admins can update materials" ON public.study_materials FOR UPDATE TO authenticated USING (public.is_admin(auth.uid()));
CREATE POLICY "Admins can delete materials" ON public.study_materials FOR DELETE TO authenticated USING (public.is_admin(auth.uid()));

-- 9. Replace write policies on contact_messages (keep public INSERT for contact form)
DROP POLICY "Authenticated users can update messages" ON public.contact_messages;
DROP POLICY "Authenticated users can delete messages" ON public.contact_messages;
DROP POLICY "Authenticated users can view messages" ON public.contact_messages;
CREATE POLICY "Admins can view messages" ON public.contact_messages FOR SELECT TO authenticated USING (public.is_admin(auth.uid()));
CREATE POLICY "Admins can update messages" ON public.contact_messages FOR UPDATE TO authenticated USING (public.is_admin(auth.uid()));
CREATE POLICY "Admins can delete messages" ON public.contact_messages FOR DELETE TO authenticated USING (public.is_admin(auth.uid()));
