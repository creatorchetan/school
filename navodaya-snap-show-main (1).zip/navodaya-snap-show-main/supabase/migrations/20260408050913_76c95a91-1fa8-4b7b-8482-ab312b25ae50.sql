
-- Create table for school photos
CREATE TABLE public.school_photos (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  image_url TEXT NOT NULL,
  category TEXT DEFAULT 'general',
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.school_photos ENABLE ROW LEVEL SECURITY;

-- Everyone can view photos (public website)
CREATE POLICY "Anyone can view school photos"
  ON public.school_photos FOR SELECT
  USING (true);

-- Only authenticated users (admin) can insert
CREATE POLICY "Authenticated users can insert photos"
  ON public.school_photos FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Only authenticated users can delete
CREATE POLICY "Authenticated users can delete photos"
  ON public.school_photos FOR DELETE
  TO authenticated
  USING (true);

-- Create storage bucket for school photos
INSERT INTO storage.buckets (id, name, public)
VALUES ('school-photos', 'school-photos', true);

-- Anyone can view uploaded photos
CREATE POLICY "Public read access for school photos"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'school-photos');

-- Authenticated users can upload
CREATE POLICY "Authenticated users can upload school photos"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'school-photos');

-- Authenticated users can delete
CREATE POLICY "Authenticated users can delete school photos"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'school-photos');
