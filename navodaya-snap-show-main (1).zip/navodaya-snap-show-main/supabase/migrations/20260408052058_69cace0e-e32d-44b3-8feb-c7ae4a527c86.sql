
-- Table for editable site content (key-value pairs)
CREATE TABLE public.site_content (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  key TEXT NOT NULL UNIQUE,
  value TEXT NOT NULL DEFAULT '',
  section TEXT NOT NULL DEFAULT 'general',
  label TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.site_content ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view site content" ON public.site_content FOR SELECT USING (true);
CREATE POLICY "Authenticated users can insert content" ON public.site_content FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update content" ON public.site_content FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete content" ON public.site_content FOR DELETE TO authenticated USING (true);

-- Table for dynamic achievements
CREATE TABLE public.school_achievements (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  year TEXT NOT NULL DEFAULT '2024',
  icon_name TEXT NOT NULL DEFAULT 'Trophy',
  color_theme TEXT NOT NULL DEFAULT 'blue',
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.school_achievements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view achievements" ON public.school_achievements FOR SELECT USING (true);
CREATE POLICY "Authenticated users can insert achievements" ON public.school_achievements FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update achievements" ON public.school_achievements FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete achievements" ON public.school_achievements FOR DELETE TO authenticated USING (true);

-- Seed default content
INSERT INTO public.site_content (key, value, section, label) VALUES
('principal_message', '"Our school believes in nurturing every child''s potential. We focus on holistic development — academics, sports, culture, and values. Together, we aim to create responsible citizens who contribute positively to society."', 'about', 'Principal''s Message'),
('principal_name', '— The Principal, JNV', 'about', 'Principal Name'),
('school_history', 'Jawahar Navodaya Vidyalaya Buklana, Bulandshahr is a central government-funded residential school in India for talented students from rural areas. Established under the National Policy of Education 1986, JNVs provide quality education to gifted children from Class VI to XII, irrespective of their family''s socio-economic condition.', 'about', 'School History'),
('vision_mission', 'To provide good quality modern education including a strong component of culture, inculcation of values, awareness of the environment, adventure activities and physical education to talented children from rural areas.', 'about', 'Vision & Mission'),
('contact_phone', '+91 XXXXX XXXXX', 'contact', 'Phone Number'),
('contact_email', 'jnv.school@example.com', 'contact', 'Email Address'),
('contact_address', 'Jawahar Navodaya Vidyalaya, Buklana, Bulandshahr, Uttar Pradesh', 'contact', 'Address'),
('hero_motto', 'Nurturing Talent from Rural India Since 1986', 'hero', 'Hero Motto'),
('stats_students', '500+', 'stats', 'Number of Students'),
('stats_teachers', '40+', 'stats', 'Number of Teachers'),
('stats_classrooms', '30+', 'stats', 'Number of Classrooms'),
('stats_campus', '10 Acres', 'stats', 'Campus Size');
