
-- contact_messages table
CREATE TABLE public.contact_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  subject text DEFAULT '',
  message text NOT NULL,
  is_read boolean DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.contact_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert contact messages" ON public.contact_messages FOR INSERT TO public WITH CHECK (true);
CREATE POLICY "Authenticated users can view messages" ON public.contact_messages FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete messages" ON public.contact_messages FOR DELETE TO authenticated USING (true);
CREATE POLICY "Authenticated users can update messages" ON public.contact_messages FOR UPDATE TO authenticated USING (true);

-- notices table
CREATE TABLE public.notices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  text text NOT NULL,
  active boolean DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.notices ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active notices" ON public.notices FOR SELECT TO public USING (true);
CREATE POLICY "Authenticated users can insert notices" ON public.notices FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update notices" ON public.notices FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete notices" ON public.notices FOR DELETE TO authenticated USING (true);

-- study_materials table
CREATE TABLE public.study_materials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  class_number integer NOT NULL,
  category text DEFAULT 'general',
  file_url text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.study_materials ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view study materials" ON public.study_materials FOR SELECT TO public USING (true);
CREATE POLICY "Authenticated users can insert materials" ON public.study_materials FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can delete materials" ON public.study_materials FOR DELETE TO authenticated USING (true);

-- study-materials storage bucket
INSERT INTO storage.buckets (id, name, public) VALUES ('study-materials', 'study-materials', true);

CREATE POLICY "Anyone can view study materials files" ON storage.objects FOR SELECT TO public USING (bucket_id = 'study-materials');
CREATE POLICY "Authenticated users can upload study materials" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'study-materials');
CREATE POLICY "Authenticated users can delete study materials" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'study-materials');
