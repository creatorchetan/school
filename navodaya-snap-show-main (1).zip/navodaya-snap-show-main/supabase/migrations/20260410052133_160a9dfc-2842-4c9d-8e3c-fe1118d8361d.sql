
-- School Videos table
CREATE TABLE public.school_videos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  video_type text NOT NULL DEFAULT 'youtube',
  video_url text NOT NULL,
  thumbnail_url text DEFAULT '',
  display_order integer DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.school_videos ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view videos" ON public.school_videos FOR SELECT USING (true);
CREATE POLICY "Admins can insert videos" ON public.school_videos FOR INSERT TO authenticated WITH CHECK (public.is_admin(auth.uid()));
CREATE POLICY "Admins can update videos" ON public.school_videos FOR UPDATE TO authenticated USING (public.is_admin(auth.uid()));
CREATE POLICY "Admins can delete videos" ON public.school_videos FOR DELETE TO authenticated USING (public.is_admin(auth.uid()));

-- Staff Messages table
CREATE TABLE public.staff_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  role text NOT NULL DEFAULT 'Principal',
  message text NOT NULL,
  photo_url text DEFAULT '',
  display_order integer DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.staff_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view staff messages" ON public.staff_messages FOR SELECT USING (true);
CREATE POLICY "Admins can insert staff messages" ON public.staff_messages FOR INSERT TO authenticated WITH CHECK (public.is_admin(auth.uid()));
CREATE POLICY "Admins can update staff messages" ON public.staff_messages FOR UPDATE TO authenticated USING (public.is_admin(auth.uid()));
CREATE POLICY "Admins can delete staff messages" ON public.staff_messages FOR DELETE TO authenticated USING (public.is_admin(auth.uid()));
