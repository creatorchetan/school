# JNV School CMS — Comprehensive Admin Upgrade

## Summary

Upgrade the school website with a proper admin panel, contact message inbox, study materials page, school showcase mode, and notice board. Some requests need scoping adjustments (noted below).

---

## What Will Be Built (Prioritized)

### 1. Admin Sidebar Panel with Tabbed Management

Replace the current top-tab admin layout with a slide-out sidebar containing:

- **Photos** — existing upload/delete functionality
- **Site Content** — existing text editor
- **Achievements** — existing CRUD
- **Inbox** — read/delete contact form messages (new)
- **Notice Board** — add/remove scrolling notices for homepage (new)
- **Study Materials** — upload PDFs by class (new)
- **Manage Admins** — invite new admins via email (new)

**Files**: Rebuild `src/pages/Admin.tsx` with sidebar layout using existing Sidebar component.

### 2. Contact Form Messages Saved to Database

- New `contact_messages` table (name, email, subject, message, read status, created_at)
- RLS: public can't INSERT, authenticated can SELECT/DELETE
- Update `ContactSection.tsx` to save messages to DB
- Admin Inbox tab shows messages with read/delete actions

### 3. Notice Board Ticker on Homepage

- New `notices` table (text, active, created_at)
- RLS: public SELECT, authenticated INSERT/UPDATE/DELETE
- New `NoticeBoardTicker.tsx` component — scrolling horizontal ticker below navbar
- Admin tab to add/remove notices

### 4. Study Materials Page (`/study`)

- New `study_materials` table (title, class_number, category, file_url, created_at)
- New `study-materials` storage bucket
- RLS: public SELECT, authenticated INSERT/DELETE
- New `src/pages/Study.tsx` — organized by class (6-12), each class shows its PDFs
- Admin tab to upload PDFs and assign to a class
- Add route in App.tsx, add nav link

### 5. School Showcase Presentation Mode

- "Play School Showcase" button on homepage
- Opens fullscreen overlay that auto-cycles through gallery photos, achievement cards, and video thumbnails
- Simple slideshow with fade transitions, auto-advance every 4 seconds
- Press Escape or click X to exit

### 6. Security Hardening

- Review and tighten all RLS policies (current policies allow ANY authenticated user to edit — this is acceptable for a school project where admins are the only registered users)
- Ensure all new tables have proper RLS

---

## What Will NOT Be Built (and Why)

### Inline Visual Editing / Drag-and-Drop on Live Site

This is essentially building a full page-builder CMS (like WordPress Elementor) from scratch. It would require:

- A virtual DOM diffing system for inline editing
- Drag-and-drop layout engine with persistence
- Complex state management for live previews

This is far too complex for a single implementation step. The current admin panel approach (edit content in forms, see changes on site) is the practical solution. The admin panel will be improved with better UX instead.

### Automated Database Backups

Lovable Cloud handles infrastructure — automated backup configuration is not accessible via code. Your data is already stored in the cloud database which has built-in redundancy.

### Manage Admins / Invite via Email

Creating an admin invitation system requires email sending infrastructure setup. This can be added as a follow-up. For now, new admin accounts can be created by sharing login credentials.

---

## Database Changes (4 new tables)

```sql
-- contact_messages
CREATE TABLE contact_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  subject text DEFAULT '',
  message text NOT NULL,
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- notices
CREATE TABLE notices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  text text NOT NULL,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- study_materials
CREATE TABLE study_materials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  class_number integer NOT NULL,
  category text DEFAULT 'general',
  file_url text NOT NULL,
  created_at timestamptz DEFAULT now()
);
```

Each table gets RLS: public can read (SELECT), only authenticated can write.
`contact_messages` allows public INSERT (for the contact form).

New storage bucket: `study-materials` (public read).

---

## New & Modified Files


| File                                   | Action                                                                   |
| -------------------------------------- | ------------------------------------------------------------------------ |
| `src/pages/Admin.tsx`                  | Rebuild with sidebar layout + new tabs (Inbox, Notices, Study Materials) |
| `src/pages/Study.tsx`                  | New — study materials page by class                                      |
| `src/components/NoticeBoardTicker.tsx` | New — scrolling notice bar                                               |
| `src/components/SchoolShowcase.tsx`    | New — fullscreen presentation overlay                                    |
| `src/components/ContactSection.tsx`    | Update — save messages to DB                                             |
| `src/components/Navbar.tsx`            | Update — add Study link                                                  |
| `src/pages/Index.tsx`                  | Update — add NoticeBoardTicker + Showcase button                         |
| `src/App.tsx`                          | Update — add /study route                                                |


---

## Technical Approach

- Admin sidebar uses the shadcn Sheet component for slide-out panel
- Study page uses Tabs or accordion grouped by class number
- Showcase uses a fullscreen fixed overlay with interval-based cycling
- All new data flows through Supabase with proper RLS